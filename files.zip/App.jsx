import { useState, useEffect, useRef } from "react";

const CLAUDE_MODEL = "claude-sonnet-4-20250514";

const SUBJECTS = {
  "9": {
    science: {
      label: "Science", icon: "⚗️", color: "#22d3ee",
      topics: ["Motion & Laws of Motion", "Force & Pressure", "Work & Energy", "Sound", "Light – Reflection", "Electricity", "Cell Structure & Function", "Tissues", "Diversity in Living Organisms", "Matter – Atoms & Molecules", "Chemical Reactions", "Acids, Bases & Salts"]
    },
    commerce: {
      label: "Commerce", icon: "📊", color: "#f59e0b",
      topics: ["Introduction to Commerce", "Trade & Aids to Trade", "Banking Basics", "Insurance", "Advertising", "Consumer Protection", "Introduction to Accounts", "Basic Accounting Terms", "Accounting Equation", "Journal Entries"]
    }
  },
  "10": {
    science: {
      label: "Science", icon: "🔬", color: "#22d3ee",
      topics: ["Light – Refraction & Lenses", "Human Eye", "Electricity & Circuits", "Magnetic Effects of Current", "Sources of Energy", "Life Processes", "Control & Coordination", "Reproduction", "Heredity & Evolution", "Chemical Reactions", "Acids, Bases & Salts", "Metals & Non-Metals", "Carbon Compounds", "Periodic Classification"]
    },
    economics: {
      label: "Economics", icon: "📈", color: "#a78bfa",
      topics: ["Introduction to Economics", "Demand & Supply", "Elasticity of Demand", "Market Structures", "National Income", "Money & Banking", "Government Budget", "International Trade", "Globalisation", "Consumer Awareness"]
    },
    accounts: {
      label: "Accounts", icon: "🧾", color: "#34d399",
      topics: ["Accounting Concepts & Principles", "Journal & Ledger", "Trial Balance", "Bank Reconciliation Statement", "Depreciation", "Trading Account", "Profit & Loss Account", "Balance Sheet", "Partnership Accounts", "Company Accounts – Shares & Debentures"]
    }
  }
};

async function callClaude(messages, systemPrompt = "") {
  const apiKey = typeof import.meta !== "undefined" && import.meta.env?.VITE_ANTHROPIC_API_KEY;
  const headers = { "Content-Type": "application/json" };
  if (apiKey) {
    headers["x-api-key"] = apiKey;
    headers["anthropic-version"] = "2023-06-01";
    headers["anthropic-dangerous-direct-browser-access"] = "true";
  }
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: CLAUDE_MODEL,
      max_tokens: 1000,
      system: systemPrompt,
      messages
    })
  });
  const data = await response.json();
  return data.content?.[0]?.text || "";
}

// ── Icons ──────────────────────────────────────────────────────────────────────
const Icon = ({ name, size = 20 }) => {
  const icons = {
    home: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>,
    book: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>,
    quiz: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17" strokeWidth="3" strokeLinecap="round"/></svg>,
    video: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polygon points="23,7 16,12 23,17"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>,
    notes: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10,9 9,9 8,9"/></svg>,
    check: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><polyline points="20,6 9,17 4,12"/></svg>,
    x: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
    star: <svg width={size} height={size} fill="currentColor" viewBox="0 0 24 24"><polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/></svg>,
    arrow: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12,5 19,12 12,19"/></svg>,
    spark: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>,
    loader: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 12a9 9 0 11-6.219-8.56" strokeLinecap="round"/></svg>,
    youtube: <svg width={size} height={size} fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>,
    refresh: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="23,4 23,10 17,10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>,
    trophy: <svg width={size} height={size} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="8,21 12,17 16,21"/><line x1="12" y1="17" x2="12" y2="11"/><path d="M5 3H3v3a9 9 0 0018 0V3h-2"/><path d="M5 3h14"/></svg>,
  };
  return icons[name] || null;
};

// ── Spinner ────────────────────────────────────────────────────────────────────
const Spinner = ({ text = "Generating…" }) => (
  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, padding: "48px 0" }}>
    <div style={{ width: 48, height: 48, border: "3px solid #1e293b", borderTop: "3px solid #f59e0b", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
    <p style={{ color: "#94a3b8", fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>{text}</p>
  </div>
);

// ── Home Page ──────────────────────────────────────────────────────────────────
const HomePage = ({ setPage }) => (
  <div style={{ padding: "0 0 48px" }}>
    <div style={{ textAlign: "center", padding: "64px 24px 48px", position: "relative" }}>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 100, padding: "6px 16px", marginBottom: 24 }}>
        <Icon name="star" size={14} /><span style={{ fontSize: 12, color: "#f59e0b", fontWeight: 600, letterSpacing: 1 }}>ICSE BOARD PREP 2025</span>
      </div>
      <h1 style={{ fontSize: "clamp(36px,6vw,64px)", fontFamily: "'Playfair Display', serif", fontWeight: 700, color: "#f1f5f9", lineHeight: 1.1, marginBottom: 16 }}>
        Study Smarter.<br /><span style={{ color: "#f59e0b" }}>Score Higher.</span>
      </h1>
      <p style={{ color: "#94a3b8", fontSize: 18, maxWidth: 520, margin: "0 auto 40px", fontFamily: "'DM Sans', sans-serif", lineHeight: 1.6 }}>
        AI-powered study companion for ICSE 9th & 10th — Science, Economics & Accounts. Quizzes, notes from YouTube, board exam prep.
      </p>
      <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
        <button onClick={() => setPage("quiz")} className="btn-primary">Start a Quiz <Icon name="arrow" size={16} /></button>
        <button onClick={() => setPage("video")} className="btn-secondary"><Icon name="youtube" size={16} /> Notes from YouTube</button>
      </div>
    </div>

    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px,1fr))", gap: 16, padding: "0 24px", maxWidth: 960, margin: "0 auto" }}>
      {[
        { icon: "quiz", title: "AI Quiz Generator", desc: "Generate MCQs, true/false & short answer questions on any ICSE topic instantly.", page: "quiz", color: "#f59e0b" },
        { icon: "video", title: "YouTube → Notes", desc: "Paste any YouTube lecture URL and get structured study notes in seconds.", page: "video", color: "#22d3ee" },
        { icon: "notes", title: "Topic Notes", desc: "Generate detailed notes on any ICSE chapter — Science, Economics or Accounts.", page: "notes", color: "#a78bfa" },
        { icon: "book", title: "Subjects", desc: "Browse all ICSE 9th & 10th topics — Science, Commerce, Economics & Accounts.", page: "subjects", color: "#34d399" },
      ].map(card => (
        <div key={card.page} onClick={() => setPage(card.page)} className="feature-card" style={{ "--card-color": card.color }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, background: `${card.color}18`, display: "flex", alignItems: "center", justifyContent: "center", color: card.color, marginBottom: 16 }}>
            <Icon name={card.icon} size={24} />
          </div>
          <h3 style={{ color: "#f1f5f9", fontFamily: "'Playfair Display', serif", fontSize: 18, marginBottom: 8 }}>{card.title}</h3>
          <p style={{ color: "#64748b", fontSize: 14, lineHeight: 1.6, fontFamily: "'DM Sans', sans-serif" }}>{card.desc}</p>
        </div>
      ))}
    </div>

    <div style={{ textAlign: "center", marginTop: 48, padding: "0 24px" }}>
      <p style={{ color: "#334155", fontSize: 13, fontFamily: "'DM Sans', sans-serif" }}>
        📚 Covers Goyal Brothers Prakarshan syllabus for Class 10 · ICSE Board aligned
      </p>
    </div>
  </div>
);

// ── Subjects Page ──────────────────────────────────────────────────────────────
const SubjectsPage = ({ setPage, setQuizConfig }) => {
  const [grade, setGrade] = useState("10");
  const subjects = SUBJECTS[grade];
  return (
    <div style={{ padding: "32px 24px", maxWidth: 900, margin: "0 auto" }}>
      <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 32, marginBottom: 8 }}>Subjects</h2>
      <p style={{ color: "#64748b", marginBottom: 28, fontFamily: "'DM Sans', sans-serif" }}>Select your grade and explore topics</p>
      <div style={{ display: "flex", gap: 8, marginBottom: 32 }}>
        {["9", "10"].map(g => (
          <button key={g} onClick={() => setGrade(g)} style={{ padding: "8px 24px", borderRadius: 8, border: "none", cursor: "pointer", fontFamily: "'DM Sans', sans-serif", fontWeight: 600, fontSize: 14, background: grade === g ? "#f59e0b" : "#1e293b", color: grade === g ? "#0f172a" : "#64748b", transition: "all 0.2s" }}>
            Class {g}
          </button>
        ))}
      </div>
      {Object.entries(subjects).map(([key, subj]) => (
        <div key={key} style={{ marginBottom: 32 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
            <span style={{ fontSize: 24 }}>{subj.icon}</span>
            <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 22 }}>{subj.label}</h3>
            {key === "accounts" && <span style={{ fontSize: 11, padding: "2px 8px", background: "rgba(52,211,153,0.15)", color: "#34d399", borderRadius: 100, fontFamily: "'DM Sans', sans-serif", fontWeight: 600 }}>Goyal Brothers</span>}
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px,1fr))", gap: 10 }}>
            {subj.topics.map(topic => (
              <div key={topic} onClick={() => { setQuizConfig({ grade, subject: key, topic }); setPage("quiz"); }} className="topic-pill" style={{ "--pill-color": subj.color }}>
                <span style={{ fontSize: 13, fontFamily: "'DM Sans', sans-serif", color: "#cbd5e1" }}>{topic}</span>
                <Icon name="arrow" size={14} />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

// ── Quiz Page ──────────────────────────────────────────────────────────────────
const QuizPage = ({ initialConfig }) => {
  const [grade, setGrade] = useState(initialConfig?.grade || "10");
  const [subject, setSubject] = useState(initialConfig?.subject || "science");
  const [topic, setTopic] = useState(initialConfig?.topic || "");
  const [customTopic, setCustomTopic] = useState("");
  const [questionCount, setQuestionCount] = useState(10);
  const [quizType, setQuizType] = useState("mcq");
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState(null);

  const subjects = SUBJECTS[grade];
  const topicList = subjects[subject]?.topics || [];

  const generateQuiz = async () => {
    const finalTopic = customTopic || topic || topicList[0];
    if (!finalTopic) return;
    setLoading(true); setQuiz(null); setAnswers({}); setSubmitted(false); setScore(null);
    try {
      const prompt = `You are an expert ICSE board exam teacher. Generate a ${quizType === "mcq" ? "multiple choice" : quizType === "tf" ? "true/false" : "short answer"} quiz for Class ${grade} ICSE students on the topic: "${finalTopic}" (Subject: ${subjects[subject]?.label}).

Generate exactly ${questionCount} questions. ${quizType === "mcq" ? "Each question should have 4 options (A, B, C, D)." : ""}

Respond ONLY with valid JSON in this exact format (no markdown, no explanation):
{
  "title": "Quiz title here",
  "questions": [
    {
      "id": 1,
      "question": "Question text",
      ${quizType === "mcq" ? '"options": ["A. option1", "B. option2", "C. option3", "D. option4"],' : ""}
      "answer": "${quizType === "mcq" ? "A" : quizType === "tf" ? "True" : "short answer"}",
      "explanation": "Brief explanation"
    }
  ]
}`;
      const text = await callClaude([{ role: "user", content: prompt }]);
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setQuiz(parsed);
    } catch (e) { alert("Failed to generate quiz. Please try again."); }
    setLoading(false);
  };

  const handleSubmit = () => {
    let s = 0;
    quiz.questions.forEach(q => {
      if (answers[q.id]?.trim().toLowerCase() === q.answer.trim().toLowerCase()) s++;
    });
    setScore(s);
    setSubmitted(true);
  };

  const reset = () => { setQuiz(null); setAnswers({}); setSubmitted(false); setScore(null); };

  return (
    <div style={{ padding: "32px 24px", maxWidth: 780, margin: "0 auto" }}>
      <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 32, marginBottom: 8 }}>Quiz Generator</h2>
      <p style={{ color: "#64748b", marginBottom: 28, fontFamily: "'DM Sans', sans-serif" }}>AI-generated ICSE board-style questions</p>

      {!quiz && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
            <div>
              <label className="form-label">Grade</label>
              <div style={{ display: "flex", gap: 8 }}>
                {["9","10"].map(g => <button key={g} onClick={() => { setGrade(g); setSubject(Object.keys(SUBJECTS[g])[0]); setTopic(""); }} className={`toggle-btn ${grade===g?"active":""}`}>Class {g}</button>)}
              </div>
            </div>
            <div>
              <label className="form-label">Quiz Type</label>
              <div style={{ display: "flex", gap: 8 }}>
                {[["mcq","MCQ"],["tf","T/F"],["sa","Short"]].map(([v,l]) => <button key={v} onClick={() => setQuizType(v)} className={`toggle-btn ${quizType===v?"active":""}`}>{l}</button>)}
              </div>
            </div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="form-label">Subject</label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {Object.entries(subjects).map(([k, s]) => (
                <button key={k} onClick={() => { setSubject(k); setTopic(""); }} className={`toggle-btn ${subject===k?"active":""}`}>{s.icon} {s.label}</button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label className="form-label">Topic</label>
            <select value={topic} onChange={e => setTopic(e.target.value)} className="select-input">
              <option value="">-- Select a topic --</option>
              {topicList.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 20 }}>
            <label className="form-label">Custom Topic (optional)</label>
            <input value={customTopic} onChange={e => setCustomTopic(e.target.value)} placeholder="e.g. Refraction of Light in a glass slab" className="text-input" />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label className="form-label">Number of Questions: {questionCount}</label>
            <input type="range" min={5} max={20} value={questionCount} onChange={e => setQuestionCount(+e.target.value)} style={{ width: "100%", accentColor: "#f59e0b" }} />
          </div>
          <button onClick={generateQuiz} disabled={loading} className="btn-primary" style={{ width: "100%" }}>
            <Icon name="spark" size={16} /> Generate Quiz
          </button>
        </div>
      )}

      {loading && <Spinner text="Generating your quiz…" />}

      {quiz && !loading && (
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <h3 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 22 }}>{quiz.title}</h3>
            <button onClick={reset} className="btn-ghost"><Icon name="refresh" size={14} /> New Quiz</button>
          </div>

          {submitted && (
            <div style={{ background: score / quiz.questions.length >= 0.7 ? "rgba(52,211,153,0.1)" : "rgba(245,158,11,0.1)", border: `1px solid ${score / quiz.questions.length >= 0.7 ? "#34d399" : "#f59e0b"}`, borderRadius: 12, padding: "20px 24px", marginBottom: 24, display: "flex", alignItems: "center", gap: 16 }}>
              <Icon name="trophy" size={32} />
              <div>
                <div style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 22, fontWeight: 700 }}>{score} / {quiz.questions.length}</div>
                <div style={{ color: "#94a3b8", fontSize: 14, fontFamily: "'DM Sans', sans-serif" }}>
                  {score / quiz.questions.length >= 0.8 ? "Excellent! Board-ready performance 🎉" : score / quiz.questions.length >= 0.6 ? "Good effort! Review the explanations below." : "Keep practicing — you've got this! 💪"}
                </div>
              </div>
            </div>
          )}

          {quiz.questions.map((q, i) => {
            const isCorrect = submitted && answers[q.id]?.trim().toLowerCase() === q.answer.trim().toLowerCase();
            const isWrong = submitted && answers[q.id] && !isCorrect;
            return (
              <div key={q.id} className="quiz-card" style={{ borderColor: submitted ? (isCorrect ? "#34d39940" : isWrong ? "#f8717140" : "#1e293b") : "#1e293b" }}>
                <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
                  <span style={{ minWidth: 28, height: 28, borderRadius: 8, background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "#64748b", fontFamily: "'DM Sans', sans-serif" }}>{i+1}</span>
                  <p style={{ color: "#e2e8f0", fontFamily: "'DM Sans', sans-serif", fontSize: 15, lineHeight: 1.6, paddingTop: 4 }}>{q.question}</p>
                </div>

                {quizType === "mcq" && q.options && (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginLeft: 40 }}>
                    {q.options.map(opt => {
                      const val = opt.charAt(0);
                      const sel = answers[q.id] === val;
                      const correct = submitted && val === q.answer;
                      const wrong = submitted && sel && val !== q.answer;
                      return (
                        <button key={opt} onClick={() => !submitted && setAnswers(a => ({ ...a, [q.id]: val }))}
                          style={{ textAlign: "left", padding: "10px 14px", borderRadius: 8, border: `1px solid ${correct ? "#34d399" : wrong ? "#f87171" : sel ? "#f59e0b" : "#1e293b"}`, background: correct ? "rgba(52,211,153,0.08)" : wrong ? "rgba(248,113,113,0.08)" : sel ? "rgba(245,158,11,0.08)" : "#0f172a", color: correct ? "#34d399" : wrong ? "#f87171" : sel ? "#f59e0b" : "#94a3b8", cursor: submitted ? "default" : "pointer", fontSize: 13, fontFamily: "'DM Sans', sans-serif", transition: "all 0.15s" }}>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                )}

                {quizType === "tf" && (
                  <div style={{ display: "flex", gap: 8, marginLeft: 40 }}>
                    {["True", "False"].map(opt => {
                      const sel = answers[q.id] === opt;
                      const correct = submitted && opt === q.answer;
                      const wrong = submitted && sel && opt !== q.answer;
                      return (
                        <button key={opt} onClick={() => !submitted && setAnswers(a => ({ ...a, [q.id]: opt }))}
                          style={{ padding: "8px 24px", borderRadius: 8, border: `1px solid ${correct ? "#34d399" : wrong ? "#f87171" : sel ? "#f59e0b" : "#1e293b"}`, background: correct ? "rgba(52,211,153,0.08)" : wrong ? "rgba(248,113,113,0.08)" : sel ? "rgba(245,158,11,0.08)" : "#0f172a", color: correct ? "#34d399" : wrong ? "#f87171" : sel ? "#f59e0b" : "#94a3b8", cursor: submitted ? "default" : "pointer", fontFamily: "'DM Sans', sans-serif", fontWeight: 600, transition: "all 0.15s" }}>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                )}

                {quizType === "sa" && (
                  <input value={answers[q.id] || ""} onChange={e => !submitted && setAnswers(a => ({ ...a, [q.id]: e.target.value }))} placeholder="Type your answer…" className="text-input" style={{ marginLeft: 40, width: "calc(100% - 40px)" }} readOnly={submitted} />
                )}

                {submitted && (
                  <div style={{ marginLeft: 40, marginTop: 12, padding: "10px 14px", borderRadius: 8, background: "#0f172a", borderLeft: `3px solid ${isCorrect ? "#34d399" : "#f59e0b"}` }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                      <span style={{ color: isCorrect ? "#34d399" : "#f59e0b" }}>{isCorrect ? <Icon name="check" size={14} /> : <Icon name="x" size={14} />}</span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: isCorrect ? "#34d399" : "#f87171", fontFamily: "'DM Sans', sans-serif" }}>{isCorrect ? "Correct!" : `Answer: ${q.answer}`}</span>
                    </div>
                    <p style={{ color: "#64748b", fontSize: 13, fontFamily: "'DM Sans', sans-serif", lineHeight: 1.5 }}>{q.explanation}</p>
                  </div>
                )}
              </div>
            );
          })}

          {!submitted && (
            <button onClick={handleSubmit} className="btn-primary" style={{ width: "100%", marginTop: 8 }}>
              <Icon name="check" size={16} /> Submit Quiz
            </button>
          )}
          {submitted && (
            <button onClick={reset} className="btn-secondary" style={{ width: "100%", marginTop: 8 }}>
              <Icon name="refresh" size={16} /> Try Another Quiz
            </button>
          )}
        </div>
      )}
    </div>
  );
};

// ── Video Notes Page ───────────────────────────────────────────────────────────
const VideoPage = () => {
  const [url, setUrl] = useState("");
  const [topic, setTopic] = useState("");
  const [grade, setGrade] = useState("10");
  const [subject, setSubject] = useState("science");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [videoId, setVideoId] = useState("");

  const extractVideoId = (url) => {
    const match = url.match(/(?:v=|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : "";
  };

  const generate = async () => {
    const vid = extractVideoId(url);
    setVideoId(vid);
    setLoading(true); setNotes("");
    const finalSubject = SUBJECTS[grade][subject]?.label || subject;
    const prompt = `You are an expert ICSE teacher. A student has shared a YouTube video URL: ${url}
${topic ? `The video is about: ${topic}` : ""}
Subject: ${finalSubject}, Class ${grade} ICSE

Generate comprehensive, well-structured study notes for ICSE board exam preparation based on this topic. Even if you can't access the video, generate excellent notes on the likely content for this subject.

Format your notes as:
# [Topic Title]

## 📌 Key Concepts
(3-5 bullet points of the most important concepts)

## 📖 Detailed Notes
(Comprehensive notes with subheadings, definitions, formulas, diagrams described in text)

## 🔢 Important Formulas / Points to Remember
(If applicable)

## ❓ Likely Board Questions
(3-4 probable exam questions with brief answers)

## 📝 Summary
(A concise 3-4 line summary)

Make notes board-exam focused, precise and easy to memorize.`;
    const text = await callClaude([{ role: "user", content: prompt }]);
    setNotes(text);
    setLoading(false);
  };

  const renderNotes = (text) => {
    const lines = text.split("\n");
    return lines.map((line, i) => {
      if (line.startsWith("# ")) return <h2 key={i} style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 24, margin: "0 0 16px" }}>{line.slice(2)}</h2>;
      if (line.startsWith("## ")) return <h3 key={i} style={{ fontFamily: "'Playfair Display', serif", color: "#f59e0b", fontSize: 18, margin: "20px 0 8px" }}>{line.slice(3)}</h3>;
      if (line.startsWith("- ") || line.startsWith("* ")) return <li key={i} style={{ color: "#cbd5e1", fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.7, marginBottom: 4 }}>{line.slice(2)}</li>;
      if (/^\d+\./.test(line)) return <li key={i} style={{ color: "#cbd5e1", fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.7, marginBottom: 4, listStyle: "decimal" }}>{line.replace(/^\d+\.\s/, "")}</li>;
      if (line.trim() === "") return <div key={i} style={{ height: 8 }} />;
      return <p key={i} style={{ color: "#94a3b8", fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.7, margin: "4px 0" }}>{line}</p>;
    });
  };

  return (
    <div style={{ padding: "32px 24px", maxWidth: 780, margin: "0 auto" }}>
      <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 32, marginBottom: 8 }}>YouTube → Notes</h2>
      <p style={{ color: "#64748b", marginBottom: 28, fontFamily: "'DM Sans', sans-serif" }}>Paste any YouTube lecture and get AI study notes</p>

      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ marginBottom: 16 }}>
          <label className="form-label"><Icon name="youtube" size={14} /> YouTube URL</label>
          <input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="text-input" />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
          <div>
            <label className="form-label">Grade</label>
            <div style={{ display: "flex", gap: 8 }}>
              {["9","10"].map(g => <button key={g} onClick={() => setGrade(g)} className={`toggle-btn ${grade===g?"active":""}`}>Class {g}</button>)}
            </div>
          </div>
          <div>
            <label className="form-label">Subject</label>
            <select value={subject} onChange={e => setSubject(e.target.value)} className="select-input">
              {Object.entries(SUBJECTS[grade]).map(([k,v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
        </div>
        <div style={{ marginBottom: 20 }}>
          <label className="form-label">Topic / Video Description (helps AI generate better notes)</label>
          <input value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g. Refraction and total internal reflection" className="text-input" />
        </div>
        <button onClick={generate} disabled={!url || loading} className="btn-primary" style={{ width: "100%" }}>
          <Icon name="spark" size={16} /> Generate Notes
        </button>
      </div>

      {videoId && (
        <div style={{ borderRadius: 12, overflow: "hidden", marginBottom: 24, aspectRatio: "16/9" }}>
          <iframe width="100%" height="100%" src={`https://www.youtube.com/embed/${videoId}`} frameBorder="0" allowFullScreen style={{ display: "block" }} />
        </div>
      )}

      {loading && <Spinner text="Reading the video and generating notes…" />}

      {notes && !loading && (
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <span style={{ fontSize: 12, color: "#34d399", fontWeight: 600, fontFamily: "'DM Sans', sans-serif", letterSpacing: 0.5 }}>✓ NOTES GENERATED</span>
            <button onClick={() => navigator.clipboard?.writeText(notes)} className="btn-ghost" style={{ fontSize: 12 }}>Copy Notes</button>
          </div>
          <div>{renderNotes(notes)}</div>
        </div>
      )}
    </div>
  );
};

// ── Notes Page ─────────────────────────────────────────────────────────────────
const NotesPage = () => {
  const [grade, setGrade] = useState("10");
  const [subject, setSubject] = useState("science");
  const [topic, setTopic] = useState("");
  const [customTopic, setCustomTopic] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const subjects = SUBJECTS[grade];

  const generate = async () => {
    const finalTopic = customTopic || topic;
    if (!finalTopic) return;
    setLoading(true); setNotes("");
    const subjectLabel = subjects[subject]?.label;
    const isGoyal = grade === "10" && subject === "accounts";
    const prompt = `You are an expert ICSE teacher${isGoyal ? " specializing in Goyal Brothers Prakarshan textbook" : ""}.
Generate comprehensive study notes for ICSE Class ${grade} ${subjectLabel} on: "${finalTopic}"
${isGoyal ? "Follow the Goyal Brothers Prakarshan textbook structure and examples." : ""}

Format:
# [Topic Title]

## 📌 Overview
(2-3 lines introducing the topic)

## 📖 Core Content
(Detailed notes with all subtopics, definitions, formulas, examples)

## 💡 Key Points to Remember
(5-7 bullet points for quick revision)

## 🔢 Important Formulas / Definitions
(If applicable to the subject)

## ❓ Board Exam Questions
(5 likely questions with model answers)

## 📝 Quick Revision Summary
(3-4 line summary)

Make it board-exam focused, precise, and student-friendly.`;
    const text = await callClaude([{ role: "user", content: prompt }]);
    setNotes(text);
    setLoading(false);
  };

  const renderNotes = (text) => text.split("\n").map((line, i) => {
    if (line.startsWith("# ")) return <h2 key={i} style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 24, margin: "0 0 16px" }}>{line.slice(2)}</h2>;
    if (line.startsWith("## ")) return <h3 key={i} style={{ fontFamily: "'Playfair Display', serif", color: "#a78bfa", fontSize: 18, margin: "20px 0 8px" }}>{line.slice(3)}</h3>;
    if (line.startsWith("- ") || line.startsWith("* ")) return <li key={i} style={{ color: "#cbd5e1", fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.7, marginBottom: 4 }}>{line.slice(2)}</li>;
    if (line.trim() === "") return <div key={i} style={{ height: 8 }} />;
    return <p key={i} style={{ color: "#94a3b8", fontFamily: "'DM Sans', sans-serif", fontSize: 14, lineHeight: 1.7 }}>{line}</p>;
  });

  return (
    <div style={{ padding: "32px 24px", maxWidth: 780, margin: "0 auto" }}>
      <h2 style={{ fontFamily: "'Playfair Display', serif", color: "#f1f5f9", fontSize: 32, marginBottom: 8 }}>Topic Notes</h2>
      <p style={{ color: "#64748b", marginBottom: 28, fontFamily: "'DM Sans', sans-serif" }}>AI-generated ICSE study notes — board exam focused</p>

      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
          <div>
            <label className="form-label">Grade</label>
            <div style={{ display: "flex", gap: 8 }}>
              {["9","10"].map(g => <button key={g} onClick={() => { setGrade(g); setSubject(Object.keys(SUBJECTS[g])[0]); setTopic(""); }} className={`toggle-btn ${grade===g?"active":""}`}>Class {g}</button>)}
            </div>
          </div>
          <div>
            <label className="form-label">Subject</label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {Object.entries(subjects).map(([k, s]) => <button key={k} onClick={() => { setSubject(k); setTopic(""); }} className={`toggle-btn ${subject===k?"active":""}`}>{s.icon} {s.label}</button>)}
            </div>
          </div>
        </div>
        <div style={{ marginBottom: 16 }}>
          <label className="form-label">Select Topic</label>
          <select value={topic} onChange={e => setTopic(e.target.value)} className="select-input">
            <option value="">-- Choose a topic --</option>
            {subjects[subject]?.topics.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div style={{ marginBottom: 20 }}>
          <label className="form-label">Or enter custom topic</label>
          <input value={customTopic} onChange={e => setCustomTopic(e.target.value)} placeholder="e.g. Partnership Deed and its clauses" className="text-input" />
        </div>
        <button onClick={generate} disabled={(!topic && !customTopic) || loading} className="btn-primary" style={{ width: "100%" }}>
          <Icon name="notes" size={16} /> Generate Notes
        </button>
      </div>

      {loading && <Spinner text="Writing your study notes…" />}
      {notes && !loading && (
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <span style={{ fontSize: 12, color: "#a78bfa", fontWeight: 600, fontFamily: "'DM Sans', sans-serif", letterSpacing: 0.5 }}>✓ NOTES READY</span>
            <button onClick={() => navigator.clipboard?.writeText(notes)} className="btn-ghost" style={{ fontSize: 12 }}>Copy Notes</button>
          </div>
          <div>{renderNotes(notes)}</div>
        </div>
      )}
    </div>
  );
};

// ── Main App ───────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("home");
  const [quizConfig, setQuizConfig] = useState(null);

  const nav = [
    { id: "home", label: "Home", icon: "home" },
    { id: "subjects", label: "Subjects", icon: "book" },
    { id: "quiz", label: "Quiz", icon: "quiz" },
    { id: "video", label: "Video Notes", icon: "video" },
    { id: "notes", label: "Notes", icon: "notes" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=DM+Sans:wght@400;500;600&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #030712; color: #f1f5f9; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        .page-enter { animation: fadeUp 0.3s ease forwards; }
        .btn-primary { display: inline-flex; align-items: center; gap: 8px; background: #f59e0b; color: #0f172a; border: none; padding: 12px 24px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; font-family: 'DM Sans', sans-serif; transition: all 0.2s; letter-spacing: 0.3px; }
        .btn-primary:hover { background: #fbbf24; transform: translateY(-1px); }
        .btn-primary:disabled { opacity: 0.4; cursor: not-allowed; transform: none; }
        .btn-secondary { display: inline-flex; align-items: center; gap: 8px; background: transparent; color: #94a3b8; border: 1px solid #1e293b; padding: 12px 24px; border-radius: 10px; font-weight: 600; font-size: 14px; cursor: pointer; font-family: 'DM Sans', sans-serif; transition: all 0.2s; }
        .btn-secondary:hover { border-color: #334155; color: #f1f5f9; transform: translateY(-1px); }
        .btn-ghost { display: inline-flex; align-items: center; gap: 6px; background: transparent; color: #64748b; border: none; padding: 6px 12px; border-radius: 8px; font-size: 13px; cursor: pointer; font-family: 'DM Sans', sans-serif; transition: all 0.15s; }
        .btn-ghost:hover { color: #94a3b8; background: #1e293b; }
        .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 16px; padding: 24px; }
        .quiz-card { background: #0a1628; border: 1px solid #1e293b; border-radius: 12px; padding: 20px; margin-bottom: 16px; transition: border-color 0.2s; }
        .feature-card { background: #0a1628; border: 1px solid #1e293b; border-radius: 16px; padding: 24px; cursor: pointer; transition: all 0.2s; }
        .feature-card:hover { border-color: var(--card-color); transform: translateY(-2px); background: #0f172a; }
        .topic-pill { display: flex; align-items: center; justify-content: space-between; background: #0a1628; border: 1px solid #1e293b; border-radius: 10px; padding: 12px 16px; cursor: pointer; transition: all 0.15s; color: var(--pill-color); }
        .topic-pill:hover { border-color: var(--pill-color); background: #0f172a; }
        .form-label { display: block; font-size: 12px; font-weight: 600; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; font-family: 'DM Sans', sans-serif; }
        .toggle-btn { padding: 7px 16px; border-radius: 8px; border: 1px solid #1e293b; background: #0f172a; color: #64748b; cursor: pointer; font-size: 13px; font-weight: 600; font-family: 'DM Sans', sans-serif; transition: all 0.15s; white-space: nowrap; }
        .toggle-btn.active { background: rgba(245,158,11,0.12); border-color: rgba(245,158,11,0.4); color: #f59e0b; }
        .toggle-btn:hover:not(.active) { border-color: #334155; color: #94a3b8; }
        .select-input { width: 100%; background: #0f172a; border: 1px solid #1e293b; border-radius: 8px; padding: 10px 12px; color: #e2e8f0; font-size: 14px; font-family: 'DM Sans', sans-serif; outline: none; cursor: pointer; }
        .select-input:focus { border-color: #f59e0b; }
        .text-input { width: 100%; background: #0f172a; border: 1px solid #1e293b; border-radius: 8px; padding: 10px 14px; color: #e2e8f0; font-size: 14px; font-family: 'DM Sans', sans-serif; outline: none; }
        .text-input:focus { border-color: #f59e0b; }
        .text-input::placeholder { color: #334155; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0f172a; }
        ::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 3px; }
        ul, ol { padding-left: 20px; }
      `}</style>

      <div style={{ minHeight: "100vh", background: "#030712", backgroundImage: "radial-gradient(ellipse at 20% 20%, rgba(245,158,11,0.04) 0%, transparent 50%), radial-gradient(ellipse at 80% 80%, rgba(34,211,238,0.04) 0%, transparent 50%)" }}>
        {/* Header */}
        <header style={{ position: "sticky", top: 0, zIndex: 100, backdropFilter: "blur(12px)", background: "rgba(3,7,18,0.85)", borderBottom: "1px solid #0f172a" }}>
          <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", height: 60 }}>
            <button onClick={() => setPage("home")} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg, #f59e0b, #d97706)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>📚</div>
              <span style={{ fontFamily: "'Playfair Display', serif", fontWeight: 700, color: "#f1f5f9", fontSize: 18 }}>ICSE Study Hub</span>
            </button>
            <nav style={{ display: "flex", gap: 4 }}>
              {nav.map(n => (
                <button key={n.id} onClick={() => setPage(n.id)}
                  style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 8, border: "none", background: page === n.id ? "rgba(245,158,11,0.12)" : "transparent", color: page === n.id ? "#f59e0b" : "#64748b", cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "'DM Sans', sans-serif", transition: "all 0.15s", whiteSpace: "nowrap" }}>
                  <Icon name={n.icon} size={15} />
                  <span style={{ display: "none" }} className="nav-label">{n.label}</span>
                  <span>{n.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </header>

        {/* Page */}
        <main className="page-enter">
          {page === "home" && <HomePage setPage={setPage} />}
          {page === "subjects" && <SubjectsPage setPage={setPage} setQuizConfig={setQuizConfig} />}
          {page === "quiz" && <QuizPage initialConfig={quizConfig} />}
          {page === "video" && <VideoPage />}
          {page === "notes" && <NotesPage />}
        </main>

        <footer style={{ textAlign: "center", padding: "24px", borderTop: "1px solid #0f172a", color: "#1e293b", fontSize: 12, fontFamily: "'DM Sans', sans-serif" }}>
          ICSE Study Hub · Class 9 & 10 · Goyal Brothers Prakarshan aligned · AI-powered
        </footer>
      </div>
    </>
  );
}
